/*
  RK MOVIE CONFIGURATION
  1. Replace the two placeholder strings below with your Supabase Project URL
     and publishable/anon key.
  2. This file is public in a static website. ONLY use the publishable/anon key.
     NEVER put a service_role or secret key here.
*/
window.RK_MOVIE_CONFIG = {
  supabaseUrl: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  supabaseAnonKey: "PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE"
};
