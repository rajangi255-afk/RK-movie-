RK MOVIE WEBSITE — MOBILE SETUP GUIDE
======================================

Yeh ek static website starter hai jo Netlify Drop par host ho sakta hai.
Isme movie list, search/filter, admin sign-in aur admin ke liye movie add form hai.
Website tab tak Supabase se connect nahi hogi jab tak neeche ke steps poore na hon.

A. WEBSITE DEPLOY KARNA
1. ZIP ko extract karein.
2. Supabase configure karne ke baad website files/folder ko Netlify Drop par upload karein:
   https://app.netlify.com/drop
3. Agar aapki purani site replace karni hai, sahi Netlify site par deploy karein.
   Galat site par deploy na karein.

B. SUPABASE PROJECT
1. https://supabase.com/ par login karke project banayein.
2. Project URL aur publishable key (ya legacy anon key) copy karein.
3. supabase-config.js kholein aur placeholders replace karein:
   supabaseUrl: "https://YOUR_PROJECT_ID.supabase.co"
   supabaseAnonKey: "YOUR_PUBLIC_PUBLISHABLE_OR_ANON_KEY"
   Save karein.
   Sirf public publishable/anon key use karein. service_role/secret key kabhi nahin.

C. DATABASE TABLE
1. Supabase dashboard -> SQL Editor -> New query.
2. supabase/schema.sql ka poora text copy/paste karke Run karein.

D. ADMIN ACCOUNT
1. Supabase -> Authentication -> Users -> Add user (email/password) se admin user banayein.
   Agar email confirmation required ho, apne test account ke liye confirmation complete karein.
2. Users list se us user ka UUID copy karein.
3. SQL Editor mein yeh query UUID ke saath run karein:
   insert into public.admins (user_id)
   values ('PASTE-ADMIN-USER-UUID-HERE');
   Placeholder ko asli UUID se replace karein.
4. Website par Admin Login kholein aur isi email/password se sign in karein.
5. Admin form se movie title, poster URL, authorized watch URL add karein.

E. IMPORTANT
- Public website sirf published movies dikhati hai.
- Video URL ko yeh starter ek external link ki tarah kholta hai; video hosting/player setup alag ho sakta hai.
- Sirf apne, licensed, public-domain, ya share karne ki permission wale videos/posters add karein.
- service_role / secret key browser code mein kabhi na rakhein.
- .env files ki zaroorat nahi; yeh static site hai. Supabase config public frontend file hai, isliye usme sirf publishable/anon key honi chahiye.
- Agar purani Netlify site mein setup alert kisi doosre code se aa raha tha, is starter ko deploy karne se purana design replace ho sakta hai. Original source backup rakhein.
