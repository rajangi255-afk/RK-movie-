(() => {
  const $ = (id) => document.getElementById(id);
  const config = window.RK_MOVIE_CONFIG || {};
  const configured = config.supabaseUrl && config.supabaseAnonKey &&
    config.supabaseUrl.startsWith("https://") &&
    !config.supabaseUrl.includes("PASTE_YOUR") &&
    !config.supabaseAnonKey.includes("PASTE_YOUR");
  let client = null;
  let allMovies = [];
  let sessionUser = null;

  $("yearNow").textContent = new Date().getFullYear();

  if (configured && window.supabase?.createClient) {
    client = window.supabase.createClient(config.supabaseUrl, config.supabaseAnonKey);
    loadMovies();
    client.auth.getSession().then(({data}) => {
      sessionUser = data?.session?.user || null;
      if (sessionUser) showAdminPanel();
    });
    client.auth.onAuthStateChange((_event, session) => {
      sessionUser = session?.user || null;
      if (sessionUser) showAdminPanel();
      else $("adminPanel").hidden = true;
    });
  } else {
    $("status").classList.add("error");
    $("status").innerHTML = 'Supabase setup required. Open <b>supabase-config.js</b> and add your Project URL and publishable/anon key, then follow README_HINDI.txt.';
    $("movieCount").textContent = "Setup required";
  }

  async function loadMovies() {
    $("status").classList.remove("error");
    $("status").innerHTML = '<span class="spinner"></span> Loading your movie library…';
    const {data, error} = await client.from("movies")
      .select("id,title,description,poster_url,video_url,release_year,category,is_published,created_at")
      .eq("is_published", true)
      .order("created_at", {ascending:false});
    if (error) {
      $("status").classList.add("error");
      $("status").textContent = "Could not load movies. Check that you ran supabase/schema.sql and configured the Supabase keys. Details: " + error.message;
      $("movieCount").textContent = "Unavailable";
      return;
    }
    allMovies = data || [];
    updateYearFilter();
    renderMovies();
  }

  function updateYearFilter() {
    const select = $("yearFilter");
    const old = select.value;
    const years = [...new Set(allMovies.map(m => m.release_year).filter(Boolean))].sort((a,b)=>b-a);
    select.innerHTML = '<option value="">All years</option>' + years.map(y => `<option value="${escapeAttr(y)}">${escapeHtml(y)}</option>`).join("");
    select.value = years.includes(Number(old)) ? old : "";
  }

  function renderMovies() {
    const q = $("searchInput").value.trim().toLowerCase();
    const year = $("yearFilter").value;
    const filtered = allMovies.filter(m =>
      (!q || [m.title,m.description,m.category].some(v => String(v || "").toLowerCase().includes(q))) &&
      (!year || String(m.release_year || "") === year)
    );
    $("movieCount").textContent = `${filtered.length} ${filtered.length === 1 ? "movie" : "movies"}`;
    $("status").textContent = "";
    $("status").style.display = "none";
    if (!filtered.length) {
      $("movieGrid").innerHTML = `<div class="empty">${allMovies.length ? "No movies match your search." : "No public movies yet. Admin can add your first movie after setup."}</div>`;
      return;
    }
    $("movieGrid").innerHTML = filtered.map(m => `
      <article class="movie-card">
        <div class="movie-poster">
          ${m.poster_url ? `<img src="${escapeAttr(m.poster_url)}" alt="${escapeAttr(m.title)} poster" loading="lazy" onerror="this.remove()">` : ""}
          <span class="poster-placeholder">RK</span>
          ${m.category ? `<span class="movie-tag">${escapeHtml(m.category)}</span>` : ""}
        </div>
        <div class="movie-info">
          <h3 title="${escapeAttr(m.title)}">${escapeHtml(m.title)}</h3>
          <div class="movie-meta">${m.release_year ? escapeHtml(m.release_year) : "Year unavailable"}</div>
          <p>${escapeHtml(m.description || "Discover this title in the RK MOVIE library.")}</p>
          <button class="watch-button" type="button" data-watch="${escapeAttr(m.id)}">View details ↗</button>
        </div>
      </article>`).join("");
    $("movieGrid").querySelectorAll("[data-watch]").forEach(btn => btn.addEventListener("click", () => openMovie(btn.dataset.watch)));
  }

  function openMovie(id) {
    const m = allMovies.find(item => String(item.id) === String(id));
    if (!m) return;
    $("watchContent").innerHTML = `
      ${m.poster_url ? `<img class="watch-poster" src="${escapeAttr(m.poster_url)}" alt="">` : `<div class="watch-poster" style="display:grid;place-items:center;font-size:26px;font-weight:900;color:#fb6687">RK</div>`}
      <div class="eyebrow">RK MOVIE LIBRARY</div>
      <h2 id="watchTitle">${escapeHtml(m.title)}</h2>
      <div class="movie-meta">${m.release_year ? escapeHtml(m.release_year) : "Year unavailable"}${m.category ? " · " + escapeHtml(m.category) : ""}</div>
      <p class="watch-desc">${escapeHtml(m.description || "No description available.")}</p>
      ${m.video_url ? `<a class="button button-primary watch-link" href="${escapeAttr(m.video_url)}" target="_blank" rel="noopener noreferrer">Open authorized watch link ↗</a>` : `<p class="muted">A watch link has not been added for this title.</p>`}
      <div style="clear:both"></div>`;
    $("watchModal").hidden = false;
  }

  $("searchInput").addEventListener("input", renderMovies);
  $("yearFilter").addEventListener("change", renderMovies);

  function openAdmin() {
    $("adminModal").hidden = false;
    $("adminMessage").textContent = "";
    if (sessionUser) showAdminPanel();
  }
  function closeAdmin() { $("adminModal").hidden = true; }
  $("adminOpen").addEventListener("click", openAdmin);
  $("modalClose").addEventListener("click", closeAdmin);
  $("adminModal").querySelector("[data-close]").addEventListener("click", closeAdmin);
  $("watchClose").addEventListener("click", () => $("watchModal").hidden = true);
  $("watchModal").querySelector("[data-watch-close]").addEventListener("click", () => $("watchModal").hidden = true);
  document.addEventListener("keydown", e => { if (e.key === "Escape") { closeAdmin(); $("watchModal").hidden = true; } });

  function showAdminPanel() {
    $("adminPanel").hidden = false;
    $("loginForm").hidden = true;
    $("adminMessage").textContent = "Signed in. If saving a movie is denied, verify that your user ID is in the admins table.";
  }

  $("loginForm").addEventListener("submit", async e => {
    e.preventDefault();
    if (!client) { $("adminMessage").textContent = "Add the Supabase URL and key in supabase-config.js first."; return; }
    $("adminMessage").textContent = "Signing in…";
    const {error} = await client.auth.signInWithPassword({
      email: $("adminEmail").value.trim(),
      password: $("adminPassword").value
    });
    if (error) $("adminMessage").textContent = error.message;
    else { $("adminMessage").classList.add("success"); $("adminMessage").textContent = "Signed in."; showAdminPanel(); }
  });

  $("logoutBtn").addEventListener("click", async () => {
    if (client) await client.auth.signOut();
    sessionUser = null;
    $("adminPanel").hidden = true;
    $("loginForm").hidden = false;
    $("adminMessage").classList.remove("success");
    $("adminMessage").textContent = "Signed out.";
  });

  $("movieForm").addEventListener("submit", async e => {
    e.preventDefault();
    if (!client || !sessionUser) { $("movieMessage").textContent = "Please sign in first."; return; }
    const title = $("movieTitle").value.trim();
    const poster = $("moviePoster").value.trim();
    const video = $("movieVideo").value.trim();
    if (!title) return;
    if ((poster && !validHttpUrl(poster)) || (video && !validHttpUrl(video))) {
      $("movieMessage").textContent = "Poster and watch links must be valid https:// or http:// URLs."; return;
    }
    $("movieMessage").textContent = "Saving…";
    const row = {
      title,
      description: $("movieDescription").value.trim() || null,
      release_year: $("movieYear").value ? Number($("movieYear").value) : null,
      category: $("movieCategory").value.trim() || null,
      poster_url: poster || null,
      video_url: video || null,
      is_published: $("moviePublished").checked,
      created_by: sessionUser.id
    };
    const {error} = await client.from("movies").insert(row);
    if (error) { $("movieMessage").textContent = error.message; return; }
    $("movieMessage").classList.add("success");
    $("movieMessage").textContent = "Movie saved.";
    $("movieForm").reset();
    $("moviePublished").checked = true;
    await loadMovies();
  });

  function validHttpUrl(s) { try { const u = new URL(s); return u.protocol === "https:" || u.protocol === "http:"; } catch { return false; } }
  function escapeHtml(v) { return String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
  function escapeAttr(v) { return escapeHtml(v); }
})();
